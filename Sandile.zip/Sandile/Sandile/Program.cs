﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Sandile
{
    class Program
    {
        static void Main(string[] args)
        {
            string GoodMatch(string male, string female)
            {
                string sentence = male + "matches" + female;
                sentence = sentence.ToLower();
                int count;
                string number = "";
                for (int j = 0; j < sentence.Length; j++)
                {
                    count = 1;
                    if (sentence[j] == '#')
                    {
                        continue;
                    }
                    for (int jk = sentence.IndexOf(sentence[j]) + 1; jk < sentence.Length; jk++)
                    {
                        if (sentence[jk] == '#')
                        {
                            continue;
                        }
                        if (sentence[j] == sentence[jk])
                        {
                            count += 1;
                        }
                    }
                    sentence = sentence.Replace(sentence[j], '#');
                    number += count.ToString();
                }

                string percentage = "";
                bool y = true;
                while (y == true)
                {
                    percentage = "";
                    if (number.Length % 2 == 0)
                    {
                        int rightIndexer = number.Length - 1;
                        for (int q = 0; q < number.Length / 2; q++)
                        {
                            percentage += int.Parse(number[q].ToString()) + int.Parse(number[rightIndexer].ToString());
                            rightIndexer -= 1;
                        }
                        number = percentage;
                    }
                    else
                    {
                        decimal qwerty = number.Length / 2;
                        int rightIndexer = number.Length - 1;
                        for (int q = 0; q < Convert.ToInt32(Math.Floor(qwerty)); q++)
                        {
                            percentage += int.Parse(number[q].ToString()) + int.Parse(number[rightIndexer].ToString());
                            rightIndexer -= 1;
                        }
                        percentage += number[Convert.ToInt32(Math.Floor(qwerty))];
                        number = percentage;
                    }
                    if (number.Length == 2)
                    {
                        y = false;
                    }
                }
                if (int.Parse(number) > 80)
                {
                    return male + " matches " + female + " " + number + "%, good match";
                }
                else
                {
                    return male + " matches " + female + " " + number + "%";
                }
            }

            bool x = true;
            string firstName, secondName;
            Console.Write("Please enter first name: ");
            firstName = Console.ReadLine();
            Console.Write("Please enter second name: ");
            secondName = Console.ReadLine();

            while (x == true)
            {


                for (int t = 0; t < firstName.Length; t++)
                {
                    if (!Char.IsLetter(firstName[t]))
                    {
                        Console.WriteLine("Please enter valid first name: ");
                        firstName = Console.ReadLine();
                    }
                }

                for (int p = 0; p < secondName.Length; p++)
                {
                    if (!Char.IsLetter(secondName[p]))
                    {
                        Console.WriteLine("Please enter valid second name: ");
                        secondName = Console.ReadLine();
                    }
                }
                x = false;
            }

            Console.WriteLine(GoodMatch(firstName, secondName));

            Console.WriteLine("Please enter the path of the CSV file or else press enter to continue");
            var path = Console.ReadLine();
            if (!(path == "" || path == null))
            {
                try
                {
                    using (var reader = new StreamReader(path))
                    {
                        List<string> males = new List<string>();
                        List<string> females = new List<string>();
                        List<string> results = new List<string>();
                        string resultSet;
                        while (!reader.EndOfStream)
                        {
                            var line = reader.ReadLine();
                            var values = line.Split(';');
                            if (values[1] == "m")
                            {
                                if (!males.Contains(values[0]))
                                {
                                    males.Add(values[0]);
                                }

                            }
                            else
                            {
                                if (!females.Contains(values[0]))
                                {
                                    females.Add(values[0]);
                                }

                            }
                        }

                        try
                        {
                            StreamWriter sw = new StreamWriter(@"C:\output.txt", true);
                            for (int me = 0; me < males.Count; me++)
                            {
                                string newResult;
                                for (int mk = 0; mk < females.Count; mk++)
                                {

                                    resultSet = GoodMatch(males[me], females[mk]);
                                    if (!resultSet.Contains(','))
                                    {
                                        newResult = resultSet.Substring(resultSet.Length - 3);
                                        newResult += resultSet.Remove(resultSet.Length - 3);
                                    }
                                    else
                                    {
                                        newResult = resultSet.Substring(resultSet.IndexOf(',') - 3, 3);
                                        newResult += resultSet.Remove(resultSet.IndexOf(',') - 3, 3);
                                    }
                                    results.Add(newResult);
                                }
                            }
                            results.Sort();
                            results.Reverse();
                            string outputText;
                            string outputPercentage;
                            for (int lp = 0; lp < results.Count; lp++)
                            {
                                if (!results[lp].Contains(','))
                                {
                                    outputText = results[lp].Remove(0, 3);
                                    outputPercentage = outputText + results[lp].Substring(0, 3);
                                }
                                else
                                {
                                    outputText = results[lp].Remove(results[lp].IndexOf(','));
                                    outputPercentage = outputText.Remove(0,3) + results[lp].Substring(0, 3) + ", good match";
                                }

                                sw.WriteLine(outputPercentage);
                            }
                            sw.Close();
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("An error has occured below is the explanation");
                            Console.WriteLine("Exception: " + e.Message);
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("An error has occured below is the explanation");
                    Console.WriteLine("Exception: " + e.Message);
                }
                Console.WriteLine("Please check for output in the following path: C:\\output.txt");
                Console.ReadKey();
            }
        }
    }
}
